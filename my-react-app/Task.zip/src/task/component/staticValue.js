// For Check
const mobile = 9429613731;
const password = "abc@123";
const otp = "123456";

// Notification Values
const success = "Log In successfully"
const error = "Invalid credentials"
const invalidOTP = "Invalid OTP";
const trueOTP = "OTP Varify";


const VALUES = { mobile, password, otp, success, error, invalidOTP, trueOTP }

export default VALUES;