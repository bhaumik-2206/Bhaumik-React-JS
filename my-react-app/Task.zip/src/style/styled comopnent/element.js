import styled from "styled-components";

export const MyHeading = styled.h1`
    font-size: 40px;
`