import React from 'react'

const NewThemeComponent = () => {
    return (
        <div className='py-5'>
            <h1>New Component</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatum, deserunt vitae corrupti iusto sunt id ea architecto, qui voluptate pariatur quasi. Excepturi eos tenetur sequi recusandae debitis corrupti eligendi ipsa?</p>
        </div>
    )
}

export default NewThemeComponent;